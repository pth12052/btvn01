﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System;

abstract class ThiSinh
{
    public string SoBaoDanh { get; set; }
    public string HoTen { get; set; }
    public string DiaChi { get; set; }
    public string UuTien { get; set; }

    public abstract double TinhTongDiem();
    public abstract string KhoiThi { get; }

    public virtual void Nhap()
    {
        Console.Write("Số báo danh: ");
        SoBaoDanh = Console.ReadLine();
        Console.Write("Họ tên: ");
        HoTen = Console.ReadLine();
        Console.Write("Địa chỉ: ");
        DiaChi = Console.ReadLine();
        Console.Write("Ưu tiên: ");
        UuTien = Console.ReadLine();
    }

    public virtual void HienThi()
    {
        Console.WriteLine($"[{KhoiThi}] {SoBaoDanh} - {HoTen} - {DiaChi} - ƯT: {UuTien} - Tổng điểm: {TinhTongDiem()}");
    }
}

class ThiSinhKhoiA : ThiSinh
{
    public double Toan, Ly, Hoa;
    public override string KhoiThi => "A";

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Điểm Toán: ");
        Toan = double.Parse(Console.ReadLine());
        Console.Write("Điểm Lý: ");
        Ly = double.Parse(Console.ReadLine());
        Console.Write("Điểm Hóa: ");
        Hoa = double.Parse(Console.ReadLine());
    }

    public override double TinhTongDiem() => Toan + Ly + Hoa;
}

class ThiSinhKhoiB : ThiSinh
{
    public double Toan, Hoa, Sinh;
    public override string KhoiThi => "B";

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Điểm Toán: ");
        Toan = double.Parse(Console.ReadLine());
        Console.Write("Điểm Hóa: ");
        Hoa = double.Parse(Console.ReadLine());
        Console.Write("Điểm Sinh: ");
        Sinh = double.Parse(Console.ReadLine());
    }

    public override double TinhTongDiem() => Toan + Hoa + Sinh;
}

class ThiSinhKhoiC : ThiSinh
{
    public double Van, Su, Dia;
    public override string KhoiThi => "C";

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Điểm Văn: ");
        Van = double.Parse(Console.ReadLine());
        Console.Write("Điểm Sử: ");
        Su = double.Parse(Console.ReadLine());
        Console.Write("Điểm Địa: ");
        Dia = double.Parse(Console.ReadLine());
    }

    public override double TinhTongDiem() => Van + Su + Dia;
}

