﻿using System;

namespace Bai4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            KhuPho khuPho = new KhuPho();
            int luaChon;

            do
            {
                Console.WriteLine("\n--- MENU QUẢN LÝ KHU PHỐ ---");
                Console.WriteLine("1. Nhập danh sách hộ dân");
                Console.WriteLine("2. Hiển thị toàn bộ hộ dân");
                Console.WriteLine("3. Tìm kiếm theo họ tên");
                Console.WriteLine("4. Tìm kiếm theo số nhà");
                Console.WriteLine("0. Thoát");
                Console.Write("Chọn: ");
                luaChon = int.Parse(Console.ReadLine());

                switch (luaChon)
                {
                    case 1:
                        khuPho.NhapDanhSachHoDan();
                        break;
                    case 2:
                        khuPho.HienThiTatCa();
                        break;
                    case 3:
                        Console.Write("Nhập họ tên cần tìm: ");
                        string ten = Console.ReadLine();
                        khuPho.TimTheoTen(ten);
                        break;
                    case 4:
                        Console.Write("Nhập số nhà cần tìm: ");
                        int soNha = int.Parse(Console.ReadLine());
                        khuPho.TimTheoSoNha(soNha);
                        break;
                    case 0:
                        Console.WriteLine("Kết thúc chương trình.");
                        break;
                    default:
                        Console.WriteLine("Lựa chọn không hợp lệ!");
                        break;
                }

            } while (luaChon != 0);
        }
    }
}
