﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class MaTran
{
    public int SoDong { get; set; }
    public int SoCot { get; set; }
    public double[,] DuLieu { get; set; }

    // Hàm tạo không đối
    public MaTran()
    {
        SoDong = 0;
        SoCot = 0;
        DuLieu = new double[0, 0];
    }

    // Hàm tạo có đối số
    public MaTran(int n, int m)
    {
        SoDong = n;
        SoCot = m;
        DuLieu = new double[n, m];
    }

    // Nhập ma trận
    public void Nhap(string ten)
    {
        Console.WriteLine($"\nNhập ma trận {ten}: ");
        Console.Write("Số dòng: ");
        SoDong = int.Parse(Console.ReadLine());
        Console.Write("Số cột: ");
        SoCot = int.Parse(Console.ReadLine());

        DuLieu = new double[SoDong, SoCot];

        for (int i = 0; i < SoDong; i++)
        {
            for (int j = 0; j < SoCot; j++)
            {
                Console.Write($"[{i},{j}] = ");
                DuLieu[i, j] = double.Parse(Console.ReadLine());
            }
        }
    }

    // Hiển thị ma trận
    public void Xuat(string moTa = "")
    {
        if (!string.IsNullOrEmpty(moTa))
            Console.WriteLine($"\n{moTa}:");
        for (int i = 0; i < SoDong; i++)
        {
            for (int j = 0; j < SoCot; j++)
            {
                Console.Write($"{DuLieu[i, j],8:F2} ");
            }
            Console.WriteLine();
        }
    }

    // Tính tổng hai ma trận
    public MaTran Cong(MaTran b)
    {
        if (SoDong != b.SoDong || SoCot != b.SoCot)
            throw new Exception("Hai ma trận không cùng kích thước!");

        MaTran kq = new MaTran(SoDong, SoCot);
        for (int i = 0; i < SoDong; i++)
        {
            for (int j = 0; j < SoCot; j++)
            {
                kq.DuLieu[i, j] = this.DuLieu[i, j] + b.DuLieu[i, j];
            }
        }
        return kq;
    }

    // Tính hiệu hai ma trận
    public MaTran Tru(MaTran b)
    {
        if (SoDong != b.SoDong || SoCot != b.SoCot)
            throw new Exception("Hai ma trận không cùng kích thước!");

        MaTran kq = new MaTran(SoDong, SoCot);
        for (int i = 0; i < SoDong; i++)
        {
            for (int j = 0; j < SoCot; j++)
            {
                kq.DuLieu[i, j] = this.DuLieu[i, j] - b.DuLieu[i, j];
            }
        }
        return kq;
    }

    // Tính tích hai ma trận
    public MaTran Nhan(MaTran b)
    {
        if (this.SoCot != b.SoDong)
            throw new Exception("Số cột ma trận A phải bằng số dòng ma trận B để nhân!");

        MaTran kq = new MaTran(this.SoDong, b.SoCot);
        for (int i = 0; i < kq.SoDong; i++)
        {
            for (int j = 0; j < kq.SoCot; j++)
            {
                for (int k = 0; k < this.SoCot; k++)
                {
                    kq.DuLieu[i, j] += this.DuLieu[i, k] * b.DuLieu[k, j];
                }
            }
        }
        return kq;
    }

    // Tính thương hai ma trận (chia từng phần tử)
    public MaTran Chia(MaTran b)
    {
        if (SoDong != b.SoDong || SoCot != b.SoCot)
            throw new Exception("Hai ma trận không cùng kích thước!");

        MaTran kq = new MaTran(SoDong, SoCot);
        for (int i = 0; i < SoDong; i++)
        {
            for (int j = 0; j < SoCot; j++)
            {
                if (b.DuLieu[i, j] == 0)
                    throw new DivideByZeroException($"Phần tử [{i},{j}] của ma trận B bằng 0!");

                kq.DuLieu[i, j] = this.DuLieu[i, j] / b.DuLieu[i, j];
            }
        }
        return kq;
    }
}
