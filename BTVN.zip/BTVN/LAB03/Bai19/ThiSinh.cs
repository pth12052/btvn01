﻿    using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class Ten
{
    public string Ho { get; set; }
    public string Dem { get; set; }
    public string TenChinh { get; set; }

    public override string ToString()
    {
        return $"{Ho} {Dem} {TenChinh}";
    }
}

public class QueQuan
{
    public string Xa { get; set; }
    public string Huyen { get; set; }
    public string Tinh { get; set; }

    public override string ToString()
    {
        return $"{Xa}, {Huyen}, {Tinh}";
    }
}

public class Diem
{
    public float Toan { get; set; }
    public float Ly { get; set; }
    public float Hoa { get; set; }

    public float TongDiem => Toan + Ly + Hoa;
}

public class ThiSinh
{
    public Ten HoTen { get; set; } = new Ten();
    public QueQuan DiaChi { get; set; } = new QueQuan();
    public string Truong { get; set; }
    public int Tuoi { get; set; }
    public string SoBaoDanh { get; set; }
    public Diem DiemThi { get; set; } = new Diem();

    public void Nhap()
    {
        Console.Write("Họ: ");
        HoTen.Ho = Console.ReadLine();
        Console.Write("Tên đệm: ");
        HoTen.Dem = Console.ReadLine();
        Console.Write("Tên: ");
        HoTen.TenChinh = Console.ReadLine();

        Console.Write("Xã: ");
        DiaChi.Xa = Console.ReadLine();
        Console.Write("Huyện: ");
        DiaChi.Huyen = Console.ReadLine();
        Console.Write("Tỉnh: ");
        DiaChi.Tinh = Console.ReadLine();

        Console.Write("Trường: ");
        Truong = Console.ReadLine();
        Console.Write("Tuổi: ");
        Tuoi = int.Parse(Console.ReadLine());

        Console.Write("Số báo danh: ");
        SoBaoDanh = Console.ReadLine();

        Console.Write("Điểm Toán: ");
        DiemThi.Toan = float.Parse(Console.ReadLine());

        Console.Write("Điểm Lý: ");
        DiemThi.Ly = float.Parse(Console.ReadLine());

        Console.Write("Điểm Hóa: ");
        DiemThi.Hoa = float.Parse(Console.ReadLine());
    }

    public void HienThi()
    {
        Console.WriteLine($"{HoTen,-25} | {DiaChi,-30} | {SoBaoDanh,-10} | {DiemThi.Toan,-5} | {DiemThi.Ly,-5} | {DiemThi.Hoa,-5} | {DiemThi.TongDiem,-5}");
    }
}

