﻿using System;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        QuanLyHocSinh qlhs = new QuanLyHocSinh();
        int chon;

        do
        {
            Console.WriteLine("\n====== MENU QUẢN LÝ HỌC SINH ======");
            Console.WriteLine("1. Nhập danh sách học sinh");
            Console.WriteLine("2. Hiển thị danh sách học sinh");
            Console.WriteLine("3. Hiển thị học sinh nữ sinh năm 1985");
            Console.WriteLine("4. Tìm học sinh theo quê quán");
            Console.WriteLine("0. Thoát");
            Console.Write("Chọn chức năng: ");
            chon = int.Parse(Console.ReadLine());

            switch (chon)
            {
                case 1:
                    qlhs.NhapDS();
                    break;
                case 2:
                    qlhs.HienThiDS();
                    break;
                case 3:
                    qlhs.HienThiHocSinhNu1985();
                    break;
                case 4:
                    Console.Write("Nhập quê quán cần tìm: ");
                    string que = Console.ReadLine();
                    qlhs.TimTheoQueQuan(que);
                    break;
                case 0:
                    Console.WriteLine("Đã thoát chương trình.");
                    break;
                default:
                    Console.WriteLine("Chức năng không hợp lệ!");
                    break;
            }

        } while (chon != 0);
    }
}

