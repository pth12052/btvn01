﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class QLHocSinh
{
    private List<HocSinh> danhSach = new List<HocSinh>();

    public void Nhap()
    {
        Console.Write("Nhập số lượng học sinh: ");
        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"\n--- Nhập học sinh thứ {i + 1} ---");
            HocSinh hs = new HocSinh();
            hs.Nhap();
            danhSach.Add(hs);
        }
    }

    public void SapXepVaHienThi()
    {
        var sapXep = danhSach
            .OrderByDescending(hs => hs.TongDiem)
            .ThenBy(hs => hs.NamSinh)
            .ToList();

        Console.WriteLine("\n===== DANH SÁCH SAU KHI SẮP XẾP =====");
        Console.WriteLine($"{"Họ tên",-30} | {"Năm sinh",-10} | {"Tổng điểm",-10}");
        Console.WriteLine(new string('-', 60));
        foreach (var hs in sapXep)
        {
            hs.Xuat();
        }
    }
}
