﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        QuanLyBienLai qlbl = new QuanLyBienLai();
        int chon;

        do
        {
            Console.WriteLine("\n====== MENU ======");
            Console.WriteLine("1. Nhập danh sách biên lai");
            Console.WriteLine("2. Hiển thị danh sách biên lai");
            Console.WriteLine("0. Thoát");
            Console.Write("Chọn chức năng: ");
            chon = int.Parse(Console.ReadLine());

            switch (chon)
            {
                case 1:
                    qlbl.NhapDanhSach();
                    break;
                case 2:
                    qlbl.HienThiDanhSach();
                    break;
                case 0:
                    Console.WriteLine("Kết thúc chương trình.");
                    break;
                default:
                    Console.WriteLine("Lựa chọn không hợp lệ!");
                    break;
            }

        } while (chon != 0);
    }
}
