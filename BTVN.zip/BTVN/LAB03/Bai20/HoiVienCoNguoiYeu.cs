﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class HoiVienCoNguoiYeu : HoiVien
{
    public string TenNguoiYeu { get; set; }
    public string SDTNguoiYeu { get; set; }

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Nhập tên người yêu: ");
        TenNguoiYeu = Console.ReadLine();
        Console.Write("Nhập số điện thoại người yêu: ");
        SDTNguoiYeu = Console.ReadLine();
    }

    public override void Xuat()
    {
        base.Xuat();
        Console.WriteLine($"Người yêu: {TenNguoiYeu}, SĐT: {SDTNguoiYeu}");
    }
}